function Onclick_container() {
	var Container = document.getElementById("container");
    if (Container.style.display === "none") {
        Container.style.display = "block";
    } 
	else{
		Container.style.display = "block";
	}

	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}

	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}

	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}

	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}

	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}

	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}

function Onclick_Introduce() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "none") {
        Introduce.style.display = "block";
    } 
	else{
		Introduce.style.display = "block";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}
function Onclick_Protection() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "none") {
        Protection.style.display = "block";
    } 
	else{
		Protection.style.display = "block";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}

function Onclick_Educate() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "none") {
        Educate.style.display = "block";
    } 
	else{
		Educate.style.display = "block";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}

function Onclick_Significance() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "none") {
        Significance.style.display = "block";
    } 
	else{
		Significance.style.display = "block";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}

function Onclick_Measure() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "none") {
        Measure.style.display = "block";
    } 
	else{
		Measure.style.display = "block";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "block") {
        Scenert.style.display = "none";
    } 
	else{
		Scenert.style.display = "none";
	}
}
function Onclick_Scenert() {
	var Container = document.getElementById("container");
    if (Container.style.display === "block") {
        Container.style.display = "none";
    } 
	else{
		Container.style.display = "none";
	}
	
	var Introduce = document.getElementById("Introduce");
    if (Introduce.style.display === "block") {
        Introduce.style.display = "none";
    } 
	else{
		Introduce.style.display = "none";
	}
	var Protection = document.getElementById("Protection");
    if (Protection.style.display === "block") {
        Protection.style.display = "none";
    } 
	else{
		Protection.style.display = "none";
	}
	var Educate = document.getElementById("Educate");
    if (Educate.style.display === "block") {
        Educate.style.display = "none";
    } 
	else{
		Educate.style.display = "none";
	}
	var Significance = document.getElementById("Significance");
    if (Significance.style.display === "block") {
        Significance.style.display = "none";
    } 
	else{
		Significance.style.display = "none";
	}
	var Measure = document.getElementById("Measure");
    if (Measure.style.display === "block") {
        Measure.style.display = "none";
    } 
	else{
		Measure.style.display = "none";
	}
	var Scenert = document.getElementById("Scenert");
    if (Scenert.style.display === "none") {
        Scenert.style.display = "block";
    } 
	else{
		Scenert.style.display = "block";
	}
}